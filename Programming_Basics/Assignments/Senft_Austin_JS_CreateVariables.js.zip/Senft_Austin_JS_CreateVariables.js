var minimumHeightInInches = 42;
var minimumAge = 10 ;

//I wanted to make sure the height variable was in inches 
//I also wanted age to be minimum age to allow for older ages