
var heightInInches = 52;
var Age = 10;
// height changed from 42 inches to 52 inches between assignments 

if ( heightInInches >= 52 || Age >= 10 ) {    
    console.log("Get on that ride, kiddo!");
}
else {    
    console.log( "Sorry kiddo. Maybe next year.");
}
// message logic based on stretch feature 1 and 2