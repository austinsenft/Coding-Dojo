//Predict 1
function myBirthYearFunc(){
    console.log("I was born in " + 1980);
}
// Console will state  "I was born in 1980"

//Predict 2 
function myBirthYearFunc(birthYearInput){
    console.log("I was born in " + birthYearInput);
}
// Console will state "I was born in 1980" (assignment mentioned birthYearInput 
// was 1980)

//Predict 3 
var num1 = 10 
var num2 = 20
function add(num1, num2){
    console.log("Summing Numbers!");
    console.log("num1 is: " + num1);
    console.log("num2 is: " + num2);
    var sum = num1 + num2;
    console.log(sum);
} 
// Console will state "30" 
