import React from 'react';

const Error = () => {
    return (
    <div>
        <h1>404 page not found</h1>
        <img src="https://pa1.narvii.com/6090/cef1d79bb0ce2290f1623000826444b0d6622424_hq.gif" alt="These are not the droids you are looking for" />
    </div>
    )
};

export default Error;