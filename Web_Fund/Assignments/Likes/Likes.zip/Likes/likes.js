
function first(element) {
    document.querySelector("#first").innerHTML++

}

function second(element) {
    document.querySelector("#second").innerHTML++

}

function third(element) {
    document.querySelector("#third").innerHTML++

}