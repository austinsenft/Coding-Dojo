package com.austinsenft.dojosandninjas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DojosAndNinjasApplicationTests {

	@Test
	void contextLoads() {
	}

}
