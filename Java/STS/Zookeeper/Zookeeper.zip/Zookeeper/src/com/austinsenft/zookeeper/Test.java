package com.austinsenft.zookeeper;

public class Test {

	public static void main(String[] args) {
		
		// Gorilla Tests
		Gorilla Harambe = new Gorilla(); 
		Harambe.throwThings(); 
		Harambe.throwThings(); 
		Harambe.throwThings();  
		
		Harambe.eatBananas();
		Harambe.eatBananas();
		
		Harambe.climb(); 
		
		Harambe.getEnergyLevel(); 
		
		// Giant Bat Tests 
		GiantBat Mothra = new GiantBat();
		Mothra.attackTown(); 
		Mothra.attackTown(); 
		Mothra.attackTown(); 
		
		Mothra.eatHumans();
		Mothra.eatHumans();
		
		Mothra.fly(); 
		Mothra.fly(); 
		
		Mothra.getEnergyLevel();
	}

}
