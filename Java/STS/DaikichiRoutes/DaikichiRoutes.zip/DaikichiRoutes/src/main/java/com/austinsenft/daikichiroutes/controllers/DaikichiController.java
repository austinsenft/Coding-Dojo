package com.austinsenft.daikichiroutes.controllers;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DaikichiController {
    @RequestMapping("/")
    public String hello() {
            return "Hello World!";
    }
    
    @RequestMapping("/daikichi")
    public String wlecome() {
            return "Welcome!";
    }
    
    @RequestMapping("/daikichi/today")
    public String fortuneToday() {
            return "Today you will find luck in all your endeavours!";
    }
    
    @RequestMapping("/daikichi/tomorrow")
    public String fortuneTomorrow() {
            return "Tomorrow, an opportunity will arise, so be sure to be open to new ideas!";
    }
}


